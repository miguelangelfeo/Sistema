public class Dispositivos implements Usuario {

    @Override
    public void actualizar_estado() {

    }
}
