public interface Usuario {

    void actualizar_estado();
}
