class Mensajeria {

    public void mensaje() {

    }

    public void eliminar_dispositivo(){

    }

    public void añadir_dispositivo(){

    }

    public void notificar_dispositivo(){

    }
}
